    

The BikeShare Project aims at giving users a quick exploration of 
    data about the customers of a bike sharing company. It enables 
    users to view data from three cities; Chicago, Washington and 
    New York City. The program also computes summary statistics 
    and returns interactive output in a simple way.

    For this project, I have used the provided datasets in csv format,
    with help from the Knowledge base of Udacity. I also had some
    help from ChatGPT with debugging code, and some video tutorials
    on YouTube.